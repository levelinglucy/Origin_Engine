from origin_engine import EngineConfig

ABLATIONS = {
    "full": EngineConfig(),
    "no_self_model": EngineConfig(use_self_model=False),
    "random_choice": EngineConfig(use_endogenous_choice=False),
    "no_persistence": EngineConfig(use_persistence=False),
    "no_echoes": EngineConfig(use_echoes=False),
}
