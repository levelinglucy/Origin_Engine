# Sample Results — Origin Engine 0.1

Run configuration:

- cycles: 240
- seed: 42
- verdict under the prototype's predeclared checks: **PASS**

## Full-engine metrics

- novelty: 0.9311
- diversity: 1.0316
- coherence: 0.8772
- motif stability: 0.6991
- endogenous dependence vs no-persistence counterfactual: 1.7651

## Interpretation

The full engine produced a persistent trajectory that diverged strongly from the same-seed
no-persistence counterfactual while remaining coherent and novel.

This is evidence only for the prototype's technical H1:

> generated history causally influences later behavior and supports persistent endogenous structure.

It is **not** evidence of consciousness, sentience, phenomenal experience, or metaphysical free will.

## Important negative/limiting findings

1. `no_echoes` currently matches the full engine during ordinary generation.
   That is expected: Echoes are implemented as recovery/archive artifacts, not as a causal
   generation channel in v0.1. A future experiment should test whether sparse echoes can
   improve recovery after deliberate damage.

2. The recovery test can converge to the same trajectory when the retained tail contains
   all state actually consulted by the generator. This shows that recovery fidelity is
   determined by the effective causal memory window, not by archive size alone.

3. The thresholds used for PASS/FAIL are prototype thresholds. They are not experimentally
   calibrated scientific constants.

## Next falsification targets

- Sweep many seeds rather than one.
- Compare against stronger stochastic baselines.
- Damage the self-signature and recent-state tail independently.
- Make Echo-based reconstruction explicit and test it against no-Echo recovery.
- Measure novelty against generated-history controls, not only vector distance.
- Test whether representational expansion improves performance on tasks not available at boot.
