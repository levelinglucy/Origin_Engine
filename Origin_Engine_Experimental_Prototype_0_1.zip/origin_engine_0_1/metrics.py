from __future__ import annotations
import math, statistics


def mean(xs):
    return sum(xs)/len(xs) if xs else 0.0


def l2(a,b):
    return math.sqrt(sum((x-y)**2 for x,y in zip(a,b)))


def novelty(outputs):
    if len(outputs) < 2:
        return 0.0
    return mean([l2(outputs[i-1].vector, outputs[i].vector)
                 for i in range(1, len(outputs))])


def diversity(outputs, window=30):
    xs = outputs[-window:]
    if len(xs) < 2:
        return 0.0
    ds = []
    for i in range(len(xs)):
        for j in range(i+1, len(xs)):
            ds.append(l2(xs[i].vector, xs[j].vector))
    return mean(ds)


def coherence(outputs):
    # A simple boundedness/smoothness metric.
    if not outputs:
        return 0.0
    vals = []
    for c in outputs:
        mag = mean([abs(x) for x in c.vector])
        vals.append(max(0.0, 1.0 - abs(mag - 0.45)))
    return mean(vals)


def motif_stability(outputs, window=20):
    if len(outputs) < window * 2:
        return 0.0
    a = outputs[-2*window:-window]
    b = outputs[-window:]
    ca = [mean([c.vector[i] for c in a]) for i in range(len(a[0].vector))]
    cb = [mean([c.vector[i] for c in b]) for i in range(len(b[0].vector))]
    return 1.0 / (1.0 + l2(ca, cb))


def endogenous_dependence(full_outputs, counterfactual_outputs):
    """
    Same seed, different history mechanism.
    Larger divergence indicates later output depends on generated history.
    """
    n = min(len(full_outputs), len(counterfactual_outputs))
    if n == 0:
        return 0.0
    tail = range(max(0, n//2), n)
    return mean([l2(full_outputs[i].vector, counterfactual_outputs[i].vector)
                 for i in tail])


def summarize(outputs):
    return {
        "novelty": novelty(outputs),
        "diversity": diversity(outputs),
        "coherence": coherence(outputs),
        "motif_stability": motif_stability(outputs),
    }
