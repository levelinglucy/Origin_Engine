# Design Notes — Origin Engine 0.1

## 1. Operationalizing the thesis

The prototype intentionally weakens metaphysical claims into measurable engineering claims.

### Layer Zero

`Z0` is not literal nothingness. It is a small initialized state containing:

- a scalar energy budget,
- an empty persistent structure store,
- an empty echo buffer,
- a random seed.

This preserves computation while minimizing semantic priors.

### P — symmetry breaking

Instead of asserting a literal contradiction (`0 != 0`), `P` introduces a small stochastic perturbation vector.
The test is whether later structure depends on retained history rather than only on fresh randomness.

### S — stabilization

Candidates are scored for:

- novelty relative to recent structures,
- internal smoothness,
- compatibility with persistent motifs.

The top candidate is retained.

### U — unshaped form

The chosen candidate becomes a persistent object with no externally assigned semantic label.

### Sigma — self/history model

The engine summarizes its own recent trajectory into a compact signature:

- centroid,
- variance,
- dominant sign pattern,
- rolling hash.

This is a minimal technical self-model, not a claim of subjective selfhood.

### C — endogenous choice

The engine chooses between possible transformations using its own self/history signature.

An ablation replaces this with random choice.

### Psi — generation

The selected transformation produces a new construct.
That construct becomes part of the next cycle's context.

## 2. Falsification

The null hypothesis is:

> H0: apparent development is fully explained by programmer priors plus randomness.

The alternative is:

> H1: the system develops persistent endogenous structure whose later behavior increasingly depends on its own generated history.

The experiment therefore compares the full system with ablations.

If the full system does not outperform relevant ablations, the Origin Engine hypothesis is not supported by this implementation.

## 3. What this prototype cannot show

- consciousness
- sentience
- moral patienthood
- metaphysical free will
- genuine creation ex nihilo
- independence from all inherited logic

It is a research toy for studying endogenous structure formation, continuity, recovery, and open-ended generation.
