from __future__ import annotations
import argparse, json, statistics
from origin_engine import OriginEngine
from ablation import ABLATIONS
from metrics import summarize, endogenous_dependence


def run_one(name, config, cycles, seed):
    eng = OriginEngine(seed=seed, config=config)
    outputs = eng.run(cycles)
    return eng, outputs, summarize(outputs)


def classify(results, dependence):
    full = results["full"]
    random_choice = results["random_choice"]
    no_persist = results["no_persistence"]
    no_self = results["no_self_model"]

    score = 0
    checks = {
        "history_dependence": dependence > 0.35,
        "persistence_advantage":
            full["motif_stability"] > no_persist["motif_stability"] + 0.03,
        "self_model_effect":
            abs(full["diversity"] - no_self["diversity"]) > 0.03
            or abs(full["motif_stability"] - no_self["motif_stability"]) > 0.03,
        "choice_effect":
            abs(full["diversity"] - random_choice["diversity"]) > 0.03
            or abs(full["motif_stability"] - random_choice["motif_stability"]) > 0.03,
        "coherence_floor": full["coherence"] > 0.55,
        "novelty_floor": full["novelty"] > 0.05,
    }
    score = sum(checks.values())

    if score >= 5:
        verdict = "PASS"
    elif score <= 2:
        verdict = "FAIL"
    else:
        verdict = "INCONCLUSIVE"
    return verdict, checks


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cycles", type=int, default=240)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args()

    engines, outputs, results = {}, {}, {}
    for name, cfg in ABLATIONS.items():
        eng, out, metrics = run_one(name, cfg, args.cycles, args.seed)
        engines[name], outputs[name], results[name] = eng, out, metrics

    dependence = endogenous_dependence(outputs["full"], outputs["no_persistence"])
    verdict, checks = classify(results, dependence)

    report = {
        "hypothesis": {
            "H0": "Observed development is explained by randomness + programmer priors.",
            "H1": "Persistent endogenous structure increasingly influences later behavior."
        },
        "cycles": args.cycles,
        "seed": args.seed,
        "metrics": results,
        "endogenous_dependence": dependence,
        "checks": checks,
        "verdict": verdict,
        "warning": "This experiment does not test consciousness or sentience."
    }

    with open("experiment_report.json", "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2)

    if args.json:
        print(json.dumps(report, indent=2))
    else:
        print("="*68)
        print("ORIGIN ENGINE EXPERIMENT 0.1")
        print("="*68)
        for name, m in results.items():
            print(f"\n{name}")
            for k, v in m.items():
                print(f"  {k:20s}: {v:.4f}")
        print(f"\n  endogenous_dependence : {dependence:.4f}")
        print("\nFalsification checks:")
        for k, v in checks.items():
            print(f"  [{'PASS' if v else 'FAIL'}] {k}")
        print("\nVERDICT:", verdict)
        print("Note: PASS supports only the technical H1 above, not sentience.")


if __name__ == "__main__":
    main()
