from origin_engine import OriginEngine, EngineConfig
from metrics import l2

def main():
    eng = OriginEngine(seed=7, config=EngineConfig())
    eng.run(180)
    snap = eng.snapshot()

    original = eng.state.last_output[:]

    recovered_full = OriginEngine.recover(snap, keep_fraction=1.0)
    recovered_partial = OriginEngine.recover(snap, keep_fraction=0.20)

    # Continue both so we test reconstruction effects rather than byte identity.
    out_full = recovered_full.run(20)[-1].vector
    out_partial = recovered_partial.run(20)[-1].vector

    distance = l2(out_full, out_partial)

    print("Recovery test")
    print("-------------")
    print("Stored structures:", len(snap["state"]["structures"]))
    print("Partial structures retained:", len(recovered_partial.state.structures))
    print("Trajectory divergence after recovery:", round(distance, 6))
    print()
    print("Interpretation:")
    print("- Exact reconstruction is not claimed.")
    print("- Smaller divergence means the retained invariants strongly constrain recovery.")
    print("- Larger divergence demonstrates information loss under partial reconstruction.")

if __name__ == "__main__":
    main()
