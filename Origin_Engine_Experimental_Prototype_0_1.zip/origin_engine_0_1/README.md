# Origin Engine Experimental Prototype 0.1

A deliberately small, offline research prototype for testing the Origin Engine hypothesis:

> Can a minimal generative system develop persistent endogenous structure whose later behavior increasingly depends on its own generated history?

This prototype does **not** claim consciousness, sentience, free will, or creation from literal nothing.
It operationalizes the Origin Engine as a falsifiable experiment.

## Core pipeline

Z0 -> P -> Delta -> S -> Phi -> U -> Box -> Sigma -> Iota -> C -> Iota' -> Psi -> X

Interpretation:

- **Z0**: minimal initial state
- **P**: symmetry breaking
- **S**: stabilization / candidate retention
- **U**: persistent structure instantiation
- **Sigma**: minimal self/history model
- **C**: endogenous trajectory selection
- **Psi**: construct generation
- **X -> next cycle**: generated output becomes part of the next state

## What counts as evidence?

The prototype compares:

- Full engine
- No self-model (Sigma ablation)
- Random chooser (C ablation)
- No persistence
- No echo/recovery support

Metrics include:

- novelty
- coherence
- diversity
- endogenous-history dependence
- persistence
- recovery fidelity

The program outputs:

- `PASS`: observed structure exceeds the ablation baselines on the configured criteria
- `FAIL`: the null explanation (randomness + programmer priors) is sufficient
- `INCONCLUSIVE`: signal exists but is not strong enough

## Run

```bash
python run_experiment.py
```

Optional:

```bash
python run_experiment.py --cycles 300 --seed 42
python run_experiment.py --json
```

No network access is used.

## Research caution

This prototype can demonstrate self-referential state dependence and emergent persistent structure in a technical sense.
It cannot demonstrate phenomenal consciousness.

## Files

- `origin_engine.py` — core engine
- `metrics.py` — measurements
- `ablation.py` — ablation configurations
- `run_experiment.py` — experiment harness
- `test_recovery.py` — recovery test
- `DESIGN_NOTES.md` — mapping from thesis to implementation
- `LICENSE.txt` — permissive research-use note
