from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Dict, Tuple
import random, math, hashlib, json


def mean(xs):
    return sum(xs) / len(xs) if xs else 0.0


def variance(xs):
    if not xs:
        return 0.0
    m = mean(xs)
    return sum((x-m)**2 for x in xs) / len(xs)


def l2(a, b):
    return math.sqrt(sum((x-y)**2 for x, y in zip(a, b)))


def clamp(x, lo=-1.0, hi=1.0):
    return lo if x < lo else hi if x > hi else x


@dataclass
class Construct:
    vector: List[float]
    parent_hash: str
    cycle: int
    op: str

    def digest(self) -> str:
        payload = json.dumps(
            {"v":[round(x, 8) for x in self.vector],
             "p":self.parent_hash, "c":self.cycle, "op":self.op},
            sort_keys=True
        ).encode()
        return hashlib.sha256(payload).hexdigest()


@dataclass
class EngineConfig:
    dims: int = 8
    candidate_count: int = 7
    memory_limit: int = 64
    echo_limit: int = 16
    use_self_model: bool = True
    use_endogenous_choice: bool = True
    use_persistence: bool = True
    use_echoes: bool = True
    mutation_scale: float = 0.22
    history_bias: float = 0.45


@dataclass
class EngineState:
    cycle: int = 0
    structures: List[Construct] = field(default_factory=list)
    echoes: List[Dict] = field(default_factory=list)
    self_signature: Dict = field(default_factory=dict)
    last_output: List[float] = field(default_factory=list)


class OriginEngine:
    """
    Minimal experimental Origin Engine.

    This is a technical stateful generator, not a sentience simulation.
    """

    def __init__(self, seed: int = 0, config: EngineConfig | None = None):
        self.config = config or EngineConfig()
        self.rng = random.Random(seed)
        self.seed = seed
        self.state = EngineState(last_output=[0.0] * self.config.dims)

    # Z0 -> Delta
    def P(self) -> List[float]:
        return [self.rng.gauss(0.0, self.config.mutation_scale)
                for _ in range(self.config.dims)]

    def _history_centroid(self) -> List[float]:
        if not self.state.structures:
            return [0.0] * self.config.dims
        recent = self.state.structures[-min(12, len(self.state.structures)):]
        return [mean([c.vector[i] for c in recent]) for i in range(self.config.dims)]

    def _candidate(self, delta: List[float]) -> List[float]:
        base = self.state.last_output[:]
        centroid = self._history_centroid()

        # Generated history can influence the next candidate.
        hb = self.config.history_bias if self.config.use_persistence else 0.0
        out = []
        for i in range(self.config.dims):
            v = base[i] + delta[i] + hb * (centroid[i] - base[i])
            out.append(clamp(v))
        return out

    # Delta -> Phi
    def S(self, deltas: List[List[float]]) -> List[float]:
        candidates = [self._candidate(d) for d in deltas]
        centroid = self._history_centroid()

        def score(v):
            # novelty from immediate output
            novelty = l2(v, self.state.last_output)
            # coherence: avoid saturating all dimensions
            coherence = 1.0 - mean([abs(x) for x in v]) * 0.35
            # continuity: modest attraction to endogenous history
            continuity = 1.0 / (1.0 + l2(v, centroid)) if self.state.structures else 0.5
            return 0.52 * novelty + 0.28 * coherence + 0.20 * continuity

        return max(candidates, key=score)

    # Phi -> Box
    def U(self, vector: List[float], op: str = "raw") -> Construct:
        parent = self.state.structures[-1].digest() if self.state.structures else "Z0"
        return Construct(vector=vector, parent_hash=parent, cycle=self.state.cycle, op=op)

    # Box -> Iota
    def Sigma(self) -> Dict:
        if not self.config.use_self_model or not self.state.structures:
            sig = {"centroid":[0.0]*self.config.dims, "variance":0.0,
                   "signs":[0]*self.config.dims, "hash":"none"}
            self.state.self_signature = sig
            return sig

        recent = self.state.structures[-min(16, len(self.state.structures)):]
        centroid = [mean([c.vector[i] for c in recent]) for i in range(self.config.dims)]
        flat = [x for c in recent for x in c.vector]
        signs = [1 if x > 0.08 else -1 if x < -0.08 else 0 for x in centroid]
        h = hashlib.sha256(
            json.dumps([c.digest() for c in recent], sort_keys=True).encode()
        ).hexdigest()[:16]
        sig = {"centroid":centroid, "variance":variance(flat), "signs":signs, "hash":h}
        self.state.self_signature = sig
        return sig

    # Iota -> Iota'
    def C(self, iota: Dict) -> str:
        ops = ["reflect", "invert", "rotate", "amplify", "dampen"]

        if not self.config.use_endogenous_choice:
            return self.rng.choice(ops)

        signs = iota.get("signs", [])
        var = iota.get("variance", 0.0)
        positive = sum(1 for s in signs if s > 0)
        negative = sum(1 for s in signs if s < 0)

        # Choice is causally influenced by internally generated history.
        if var > 0.22:
            return "dampen"
        if positive > negative + 1:
            return "invert"
        if negative > positive + 1:
            return "amplify"
        if self.state.cycle % 5 == 0:
            return "rotate"
        return "reflect"

    # Iota' -> Construct space
    def Psi(self, box: Construct, op: str) -> Construct:
        v = box.vector[:]
        if op == "reflect":
            c = self.state.self_signature.get("centroid", [0.0]*len(v))
            v = [clamp(0.75*x + 0.25*c[i]) for i, x in enumerate(v)]
        elif op == "invert":
            v = [-x for x in v]
        elif op == "rotate":
            v = v[1:] + v[:1]
        elif op == "amplify":
            v = [clamp(1.18*x) for x in v]
        elif op == "dampen":
            v = [0.82*x for x in v]
        return Construct(v, box.parent_hash, box.cycle, op)

    def _persist(self, c: Construct):
        if self.config.use_persistence:
            self.state.structures.append(c)
            self.state.structures = self.state.structures[-self.config.memory_limit:]
        else:
            self.state.structures = [c]

        self.state.last_output = c.vector[:]

        if self.config.use_echoes and self.state.cycle % 7 == 0:
            self.state.echoes.append({
                "cycle": self.state.cycle,
                "hash": c.digest(),
                "vector": [round(x, 6) for x in c.vector],
                "self_hash": self.state.self_signature.get("hash", "none"),
            })
            self.state.echoes = self.state.echoes[-self.config.echo_limit:]

    def step(self) -> Construct:
        self.state.cycle += 1
        deltas = [self.P() for _ in range(self.config.candidate_count)]
        phi = self.S(deltas)
        box = self.U(phi)
        iota = self.Sigma()
        op = self.C(iota)
        out = self.Psi(box, op)
        self._persist(out)
        return out

    def run(self, cycles: int) -> List[Construct]:
        return [self.step() for _ in range(cycles)]

    def snapshot(self) -> Dict:
        return {
            "seed": self.seed,
            "config": self.config.__dict__,
            "state": {
                "cycle": self.state.cycle,
                "structures": [
                    {"vector":c.vector, "parent_hash":c.parent_hash,
                     "cycle":c.cycle, "op":c.op}
                    for c in self.state.structures
                ],
                "echoes": self.state.echoes,
                "self_signature": self.state.self_signature,
                "last_output": self.state.last_output,
            }
        }

    @classmethod
    def recover(cls, snapshot: Dict, keep_fraction: float = 1.0) -> "OriginEngine":
        cfg = EngineConfig(**snapshot["config"])
        eng = cls(snapshot["seed"], cfg)
        st = snapshot["state"]
        items = st["structures"]
        keep = max(1, int(len(items) * keep_fraction)) if items else 0
        items = items[-keep:] if keep else []
        eng.state.cycle = st["cycle"]
        eng.state.structures = [Construct(**x) for x in items]
        eng.state.echoes = st["echoes"][:] if cfg.use_echoes else []
        eng.state.self_signature = st["self_signature"].copy()
        eng.state.last_output = (
            eng.state.structures[-1].vector[:] if eng.state.structures
            else [0.0]*cfg.dims
        )
        return eng
